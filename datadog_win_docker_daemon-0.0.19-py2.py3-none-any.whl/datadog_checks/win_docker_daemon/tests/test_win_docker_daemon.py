import pytest

from datadog_checks.base import ConfigurationError

from ..win_docker_daemon import WinDockerDaemonCheck


def test_empty_check(aggregator, instance):
    check = WinDockerDaemonCheck('win_docker_daemon', {}, {})

    with pytest.raises(ConfigurationError):
        check.check(instance)


def test_bad_url(aggregator, instance):
    check = WinDockerDaemonCheck('win_docker_daemon', {}, {})

    # instance = {'url': 'tcp://172.31.26.208:2375'}
    instance = {'url': 'tcp://10.130.128.15:2375'}
    check.check(instance)
    #
    # aggregator.assert_all_metrics_covered()
